<?php include 'inc/header.php'; ?>

<div class="contentsection contemplete clear">
	<div class="maincontent clear">
		<div class="about">
			<div class="notfound">
				<p><span>404</span> Not Found</p>
			</div>
		</div>
	</div>
	<?php include "inc/sidebar.php"; ?>

</div>

<?php include "inc/footer.php"; ?>